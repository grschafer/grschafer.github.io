'''
Created on Aug 12, 2011

@author: Greg
'''

import pygame, os
from pygame.locals import *

class TetraGraphicsManager(object):


    def __init__(self):
        pass
    
    @staticmethod
    def load_image(filename, rect=None, colorkey=None):
        fullname = os.path.join('..','data', filename)
        try:
            loaded_image = pygame.image.load(fullname)
        except pygame.error, message:
            print "Cannot load image:", filename
            raise SystemExit, message
        if rect is not None:
            image = pygame.Surface(rect.size).convert()
            image.blit(loaded_image, (0, 0), rect)
        else:
            image = loaded_image.convert()
        if colorkey is not None:
            if colorkey is -1:
                colorkey = image.get_at((0,0))
            image.set_colorkey(colorkey, RLEACCEL)
        return image
    
    @staticmethod
    def load_font(filename, size):
        fullname = os.path.join('..','data', filename)
        return pygame.font.Font(fullname, size)