'''
Created on Aug 12, 2011

@author: Greg
'''

from tetra_graphics_manager import TetraGraphicsManager
from pygame.locals import *
import numpy
import pygame

class Board(object):
    
    def __init__(self):
        self.BOUNDS = pygame.rect.Rect(40, 40, 400, 800)
        self.board_array = numpy.zeros((22, 12), int)
        self.board_array[21, :] = 1
        self.board_array[:, 0] = 1
        self.board_array[:, 11] = 1
        self.background = TetraGraphicsManager.load_image("board.png")
        self.blockdump = pygame.Surface((self.BOUNDS.width, self.BOUNDS.height))
        self.blockdump.set_colorkey((0, 0, 0), RLEACCEL)
    
    def check_collision(self, shape_arr, pos):
        # method 1: use graphical collision detection between controlled_block and block_dump
        # method 2: check controlled_block coverage array with board_array
#        print "checking for collisions"
#        print len(shape_arr), len(shape_arr[0])
        for row in range(0, len(shape_arr)):
            for col in range(0, len(shape_arr[row])):
                if self.board_array[row + pos[1]][col + pos[0]] == 1 and shape_arr[row][col] == 1:
                    return True
        return False
    
    def add_block_to_dump(self, block, shape_arr, pos):
        for row in range(0, len(shape_arr)):
            for col in range(0, len(shape_arr[row])):
                if shape_arr[row][col] == 1:
                    self.board_array[row + pos[1]][col + pos[0]] = 1
                    # add block image to block dump surface (map func is for offsetting by 40)
                    self.blockdump.blit(block.image, map(lambda x: x - 40, block.rect))
                    
        # check for full rows
        filledrows = self.get_filled_rows()
        for rowindex in filledrows:
            above = pygame.Rect(0, 0, 400, (rowindex + 1) * 40)
            self.blockdump.set_clip(above)
            self.blockdump.scroll(0, 40)
            self.blockdump.set_clip(None)
            
            self.board_array[1:rowindex + 2, :] = self.board_array[0:rowindex + 1, :]
        return len(filledrows)
                    
                    
    def get_filled_rows(self):
        playboard = self.board_array[1:-1, 1:-1]
        filled_rows = []
        for i in range(len(playboard)):
            if sum(playboard[i]) == len(playboard[i]):
                filled_rows.append(i)
        return filled_rows
                    
