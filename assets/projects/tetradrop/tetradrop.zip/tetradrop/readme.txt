Tetradrop

Author: Greg Schafer
Email: grschafer@gmail.com

To run:
1. Install pygame http://pygame.org/download.shtml
2. Install numpy http://new.scipy.org/download.html
3. In the src/ folder, run "python tetradrop.py"
